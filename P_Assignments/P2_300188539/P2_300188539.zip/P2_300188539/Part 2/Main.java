import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/*
-Full name : Alae Boufarrachene
-Student number : 300188539
-Course : CSI2110-D
-Assignment : P2
-Question : 2a
*/