➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : CSI2110-D
➥Programming assignment : #1
➥Academic year : 2021-2022